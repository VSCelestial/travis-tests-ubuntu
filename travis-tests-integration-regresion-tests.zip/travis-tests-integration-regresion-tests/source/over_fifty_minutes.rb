20.times do
  puts 'Something appears'
  sleep 9 * 60
end